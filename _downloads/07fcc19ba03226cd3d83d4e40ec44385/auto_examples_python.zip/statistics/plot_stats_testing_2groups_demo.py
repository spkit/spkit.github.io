"""
===============================
Testing two groups
===============================

"""
#sp.stats.test_2groups


# %%
# Example 1: Paired
# ------------------
import numpy as np
import matplotlib.pyplot as plt
import spkit as sp
np.random.seed(1)
x1 = np.random.randn(100)
x2 = np.random.randn(100)+0.2
tPass,(df1,df2) = sp.stats.test_2groups(x1,x2,paired=True,alpha=0.05,title=None,tval=True,
                    printthr=1,return_all=True,print_round=4,notes=True,pre_tests=True,effect_size=True,
                    plots=True)


print('Test Result Table')
print(df1)
print('Test Effect-size')
print(df2)

# %%
# Example 2: Unpaired
# ------------------
import numpy as np
import matplotlib.pyplot as plt
import spkit as sp
np.random.seed(1)
x1 = np.random.randn(10)
x2 = np.random.randn(11)+0
tPass,(df1,df2) = sp.stats.test_2groups(x1,x2,paired=False,alpha=0.05,title=None,tval=True,
                        printthr=1,return_all=True,
                        print_round=4,notes=True,pre_tests=True,effect_size=True,plots=True)

print('Test Result Table')
print(df1)
print('Test Effect-size')
print(df2)
