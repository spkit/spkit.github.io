r"""
==========================
EEG Artifact: ATAR and ICA
==========================

In this example we compare ICA with ATAR

"""
import numpy as np
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings("ignore")

import spkit as sp
print('spkit version :', sp.__version__)


#%%
# Load and filter EEG Signal
#----------------------------

# Load sample EEG Data ( 16 sec, 128 smapling rate, 14 channel)
# Filter signal (with IIR highpass 0.5Hz)

X, fs, ch_names = sp.data.eeg_sample_14ch()
Xf = sp.filter_X(X.copy(),fs=128.0, band=[0.5], btype='highpass',ftype='SOS')
print(Xf.shape)



#%%
# ATAR - three modes
#------------------------------

XR1 = sp.eeg.ATAR(Xf.copy(),verbose=1,OptMode='soft',winsize=128)
XR2 = sp.eeg.ATAR(Xf.copy(),verbose=1,OptMode='elim',winsize=128)
XR3 = sp.eeg.ATAR(Xf.copy(),verbose=1,OptMode='linAtten',winsize=128)


#%%
# Artifact removal using ICA
#----------------------------

XR4 = sp.eeg.ICA_filtering(Xf.copy(),winsize=128, ICA_method='extended-infomax',kur_thr=2,corr_thr=0.8,
                        AF_ch_index = [0,13] ,F_ch_index=[1,2,11,12])

XR5 = sp.eeg.ICA_filtering(Xf.copy(),winsize=128, ICA_method='infomax',kur_thr=2,corr_thr=0.8,
                        AF_ch_index = [0,13] ,F_ch_index=[1,2,11,12])

XR6 = sp.eeg.ICA_filtering(Xf.copy(),winsize=128, ICA_method='picard',kur_thr=2,corr_thr=0.8,
                        AF_ch_index = [0,13] ,F_ch_index=[1,2,11,12])



#%%
# Plots of Corrections
#----------------------

sep=150
t = np.arange(Xf.shape[0])/fs

plt.figure(figsize=(12,8))
plt.subplot(321)
plt.plot(t,XR1+np.arange(14)*sep)
plt.xlim([t[0],t[-1]])
plt.yticks([])
plt.ylabel('ATAR: Soft-thresholding')
plt.title('ATAR')
plt.subplot(322)
plt.plot(t,XR4+np.arange(14)*sep)
plt.xlim([t[0],t[-1]])
plt.yticks([])
plt.ylabel('ICA: extended-infomax')
plt.title('ICA Based')
plt.subplot(323)
plt.plot(t,XR2+np.arange(14)*sep)
plt.xlim([t[0],t[-1]])
plt.yticks([])
plt.ylabel('ATAR: Elimination')
plt.subplot(324)
plt.plot(t,XR5+np.arange(14)*sep)
plt.xlim([t[0],t[-1]])
plt.yticks([])
plt.ylabel('ICA: infomax')
plt.subplot(325)
plt.plot(t,XR3+np.arange(14)*sep)
plt.xlim([t[0],t[-1]])
plt.yticks([])
plt.ylabel('ATAR: Linear Atten.')
plt.subplot(326)
plt.plot(t,XR6+np.arange(14)*sep)
plt.xlim([t[0],t[-1]])
plt.yticks([])
plt.ylabel('ICA: picard')
plt.subplots_adjust(wspace=0.1,hspace=0.15)
plt.suptitle('Correction using : ATAR and ICA')
plt.show()

#%%
# Plots of Residuals
#----------------------


sep=150
t = np.arange(Xf.shape[0])/fs

plt.figure(figsize=(12,8))
plt.subplot(321)
plt.plot(t,Xf-XR1+np.arange(14)*sep)
plt.xlim([t[0],t[-1]])
plt.yticks([])
plt.ylabel('ATAR: Soft-thresholding')
plt.title('ATAR')
plt.subplot(322)
plt.plot(t,Xf-XR4+np.arange(14)*sep)
plt.xlim([t[0],t[-1]])
plt.yticks([])
plt.ylabel('ICA: extended-infomax')
plt.title('ICA Based')
plt.subplot(323)
plt.plot(t,Xf-XR2+np.arange(14)*sep)
plt.xlim([t[0],t[-1]])
plt.yticks([])
plt.ylabel('ATAR: Elimination')
plt.subplot(324)
plt.plot(t,Xf-XR5+np.arange(14)*sep)
plt.xlim([t[0],t[-1]])
plt.yticks([])
plt.ylabel('ICA: infomax')
plt.subplot(325)
plt.plot(t,Xf-XR3+np.arange(14)*sep)
plt.xlim([t[0],t[-1]])
plt.yticks([])
plt.ylabel('ATAR: Linear Atten.')
plt.subplot(326)
plt.plot(t,Xf-XR6+np.arange(14)*sep)
plt.xlim([t[0],t[-1]])
plt.yticks([])
plt.ylabel('ICA: picard')
plt.subplots_adjust(wspace=0.1,hspace=0.15)
plt.suptitle('Residual: Xf-XR (removed)')
plt.show()