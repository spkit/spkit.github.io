"""
================================
MEA: Minimal Setting: Example
================================

In this example code, we demonstrate analysis of MEA Recording, with minimal settings, using signle line
that includes all the 13 steps

1. Read HDF File
2. Stim loc
3. Align Cycles
4. Average Cycles/Select one
5. Activation Time
6. Activation & Repolarisation Time
7. APD computation
8. Extract EGM
9. EGM Feature Extraction
10. BAD Channels
11. Feature Matrix
12. Interpolation
13. Conduction Velocity

"""
#sp.mea
import numpy as np
import matplotlib.pyplot as plt
import os, requests
import spkit as sp
print('spkit-version: ',sp.__version__)

# Download Sample file if not done already

file_name= 'MEA_Sample_North_1000mV_1Hz.h5'

if not(os.path.exists(file_name)):
    path = 'https://spkit.github.io/data_samples/files/MEA_Sample_North_1000mV_1Hz.h5'
    req = requests.get(path)
    with open(file_name, 'wb') as f:
            f.write(req.content)

#%%

##############################
#
Features_df,Features_ch,Features_mat, Data = sp.mea.analyse_mea_file(file_name,stim_fhz=1)


#%%
# Results
#-------------

print(Features_df)


print(Features_ch)