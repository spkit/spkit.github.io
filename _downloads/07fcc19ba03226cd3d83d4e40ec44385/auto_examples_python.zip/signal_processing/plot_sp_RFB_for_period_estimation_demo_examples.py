"""
===============================
Ramanujan Filter Banks -  Demos
===============================


# Ramanujan Filter Banks

Demos

"""

import numpy as np
import matplotlib.pyplot as plt
import spkit as sp
print('spkit version :', sp.__version__)

# %%
# Example demo 1
# ------------

sp.RFB_example_1(period=10, SNR=0, seed=10)

# %%
# Example demo 2
# ------------

sp.RFB_example_2(periods=[3, 7, 11], signal_length=100, SNR=10, seed=15)

# %%
# Example demo 2 with diff periods
# ------------

sp.RFB_example_2(periods=[3,7,14], signal_length=100, SNR=10, seed=15)





