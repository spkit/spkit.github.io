"""
========================================
Decision Trees with shrinking capability - Regression example
========================================

Decision Trees with shrinking capability from SpKit (Regression example)

In this notebook, we show the capability of decision tree from ***spkit*** to analysie the training and testing performace at each depth of a trained tree. After which, a trained tree can be shrink to any smaller depth, ***without retraining it***. So, by using Decision Tree from ***spkit***, you could choose a very high number for a **max_depth** (or just choose -1, for infinity) and analysis the parformance (accuracy, mse, loss) of training and testing (practically, a validation set) sets at each depth level. Once you decide which is the right depth, you could shrink your trained tree to that layer, without explicit training it again to with new depth parameter.

"""

import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
import spkit
print('spkit version :', spkit.__version__)

# just to ensure the reproducible results
np.random.seed(100) 

# Regression - Diabetes Dataset - score

from spkit.ml import RegressionTree


from sklearn.datasets import load_diabetes
data = load_diabetes()
X = data.data
y = data.target

feature_names = data.feature_names
print(X.shape, y.shape)
Xt,Xs,yt,ys = train_test_split(X,y,test_size =0.3)
print(Xt.shape, Xs.shape,yt.shape, ys.shape)


# ### Train with max_depth=15, MSE, MAE


model = RegressionTree(max_depth=15)
model.fit(Xt,yt,feature_names=feature_names)
ytp = model.predict(Xt)
ysp = model.predict(Xs)
print('Depth of trained Tree ', model.getTreeDepth())
print('MSE')
print('- Training : ',np.mean((ytp-yt)**2))
print('- Testing  : ',np.mean((ysp-ys)**2))
print('MAE')
print('- Training : ',np.mean(np.abs(ytp-yt)))
print('- Testing  : ',np.mean(np.abs(ysp-ys)))


#  Plot trained Tree

plt.figure(figsize=(15,12))
model.plotTree()


#  Analysing the Learning Curve and Tree with MAE

Lcurve = model.getLcurve(Xt=Xt,yt=yt,Xs=Xs,ys=ys,measure='mae')
print(Lcurve)


model.plotLcurve()
plt.xlim([1,model.getTreeDepth()])
plt.xticks(np.arange(1,model.getTreeDepth()+1))
plt.show()


plt.figure(figsize=(10,8))
model.plotTree(show=False,Measures=True,showNodevalues=True,showThreshold=False)


# Shrining a trained Tree to depth=2

model.updateTree(shrink=True,max_depth=2)


ytp = model.predict(Xt)
ysp = model.predict(Xs)
print('Depth of trained Tree ', model.getTreeDepth())
print('MSE')
print('- Training : ',np.mean((ytp-yt)**2))
print('- Testing  : ',np.mean((ysp-ys)**2))
print('MAE')
print('- Training : ',np.mean(np.abs(ytp-yt)))
print('- Testing  : ',np.mean(np.abs(ysp-ys)))


plt.figure(figsize=(10,5))
model.plotTree(show=False,Measures=True,showNodevalues=True,showThreshold=True)

