"""
========================================
Release Highlights for spkit 0.0.9.6
========================================

.. currentmodule:: spkit

**Release Highlights for spkit 0.0.9.6**

We are pleased to announce the release of spkit 0.0.9.6, which comes
with more algorithms, such as Ramajuna methods and MEA and many bug fixes.
"""


# %%
# MEA: Multi-Electrode Array Processing
# -------------------------------------
#
#
# A full Documentation of MEA Processing Library is added.
#
# :ref:`mea` 
#
# .. image:: https://raw.githubusercontent.com/spkit/spkit.github.io/master/assets/images/docs_fig/mea_proce_2.png
#    :width: 800
#    :align: center
#    :target: ../../modules/bsp_mea.html#mea
#
# .. image:: https://raw.githubusercontent.com/spkit/spkit.github.io/master/assets/images/docs_fig/mea_proce_3.png
#    :width: 800
#    :align: center
#    :target: ../../modules/bsp_mea.html#mea
#
# Check Examples: :ref:`mea_examples`


# %%
# Ramanujan Methods for period estimation
# ---------------------------------------
#
#

import numpy as np
import matplotlib.pyplot as plt
import spkit as sp
# demo1
sp.RFB_example_1(period=10, SNR=0, seed=10)

# demo2
sp.RFB_example_2(periods=[3, 7, 11], signal_length=100, SNR=10, seed=15)

