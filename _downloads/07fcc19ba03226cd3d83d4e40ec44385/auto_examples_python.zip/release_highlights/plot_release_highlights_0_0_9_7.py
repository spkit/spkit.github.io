"""
========================================
Release Highlights for spkit 0.0.9.7
========================================

.. currentmodule:: spkit

We are pleased to announce the release of spkit 0.0.9.7, which comes
with many bug fixes, more organised documentation and new features!
For an exhaustive list of all the changes, please
refer to the :ref:`release notes <changes_0_0_9_7>`.
"""

# %%
# Topographic Map correction: 10-20 System
# ----------------------------------------
#
# A widely used EEG system is 10-20 system, although there are many libraries that can plot topographic map
# from EEG data, their layouts are a little different than standards.
#
# Notice the 10-20 Standard described in following
#
#   * https://www.bem.fi/book/13/13.htm#03
#   * https://en.wikipedia.org/wiki/10%E2%80%9320_system_(EEG)
#   * http://www.mariusthart.net/downloads/eeg_electrodes_10-20.pdf, http://www.beteredingen.nl
#
# In above examples, Cz is the center point and horizontal line crossing is straight line. 
# In Spkit we tried to correct this mapping style, however, keeping the conventional style as option.
# See following examples.


#sp.eeg.topomap
import numpy as np
import matplotlib.pyplot as plt
import spkit as sp
X,fs, ch_names = sp.data.eeg_sample_14ch()
X = sp.filterDC_sGolay(X, window_length=fs//3+1)
Px,Pm,Pd = sp.eeg.rhythmic_powers(X=X,fs=fs,fBands=[[4],[8,14]],Sum=True,Mean=True,SD =True)
Px = 20*np.log10(Px)
pos1, ch = sp.eeg.s1020_get_epos2d(ch_names,style='eeglab-mne')
pos2, ch = sp.eeg.s1020_get_epos2d(ch_names,style='spkit')
fig, ax = plt.subplots(1,2,figsize=(10,4))
Z1i,im1 = sp.eeg.topomap(pos=pos1,data=Px[1],axes=ax[0],return_im=True)
Z2i,im2 = sp.eeg.topomap(pos=pos2,data=Px[1],axes=ax[1],return_im=True)
ax[0].set_title(r'Conventional style')
ax[1].set_title(r'SpKit style')
plt.colorbar(im1, ax=ax[0],label='dB')
plt.colorbar(im2, ax=ax[1],label='dB')
plt.suptitle('Topographical maps')
plt.show()

# %%
# Location of all the eletrodes
# -----------------------------
# 
# Location of all the electrodes are shown here.
#

import numpy as np
import matplotlib.pyplot as plt
import spkit as sp

ch_names_emotiv = ['AF3','F7','F3','FC5','T7','P7','O1','O2','P8','T8','FC6','F4','F8','AF4']
pos1, ch1 = sp.eeg.s1020_get_epos2d(ch_names_emotiv)
pos2, ch2 = sp.eeg.s1020_get_epos2d(ch_names_emotiv,style='spkit')

ch_names_all = sp.eeg.presets.standard_1020_ch
pos3, ch3 = sp.eeg.s1020_get_epos2d(ch_names_all)

ch_names_spkit_all = sp.eeg.presets.standard_1020_spkit_ch
pos4, ch4 = sp.eeg.s1020_get_epos2d(ch_names_spkit_all,style='spkit')

plt.figure(figsize=(10,5))
plt.subplot(121)
plt.plot(pos1[:,0],pos1[:,1],'.',alpha=0.5)
for i,ch in enumerate(ch_names_emotiv):
    plt.text(pos1[i,0],pos1[i,1],ch,va='center',ha='center')
plt.title('Emotiv: 14 channels: mne-eeglab-style')
plt.axvline(0,lw=0.5,color='k',ls='--')
plt.axhline(0,lw=0.5,color='k',ls='--')
plt.subplot(122)
plt.plot(pos3[:,0],pos3[:,1],'.',alpha=0.5)
for i,ch in enumerate(ch_names_all):
    plt.text(pos3[i,0],pos3[i,1],ch,va='center',ha='center')
plt.title(f'All 10-20 Channels: (n={len(ch_names_all)})')
plt.axvline(0,lw=0.5,color='k',ls='--')
plt.axhline(0,lw=0.5,color='k',ls='--')
plt.suptitle('MNE-EEGLab style topographic map')
plt.tight_layout()
plt.show()

plt.figure(figsize=(10,5))
plt.subplot(121)
plt.plot(pos2[:,0],pos2[:,1],'.',alpha=0.5)
for i,ch in enumerate(ch_names_emotiv):
    plt.text(pos2[i,0],pos2[i,1],ch,va='center',ha='center')
plt.title('Emotiv: 14 channels')
plt.axvline(0,lw=0.5,color='k',ls='--')
plt.axhline(0,lw=0.5,color='k',ls='--')
plt.subplot(122)
plt.plot(pos4[:,0],pos4[:,1],'.',alpha=0.5)
for i,ch in enumerate(ch_names_spkit_all):
    plt.text(pos4[i,0],pos4[i,1],ch,va='center',ha='center')
plt.title(f'All 10-20 Channels: (n={len(ch_names_spkit_all)})')
plt.suptitle('SPKIT-style topographic map')
plt.axvline(0,lw=0.5,color='k',ls='--')
plt.axhline(0,lw=0.5,color='k',ls='--')
plt.tight_layout()
plt.show()




# %%
# Topographic Map 10-10 System
# ----------------------------


import numpy as np
import matplotlib.pyplot as plt
import spkit as sp

ch_names = ['AF3','F7','F3','FC5','T7','P7','O1','O2','P8','T8','FC6','F4','F8','AF4']
pos, ch = sp.eeg.s1010_get_epos2d(ch_names)

plt.figure(figsize=(12,5))

plt.subplot(121)
plt.plot(pos[:,0],pos[:,1],'.',alpha=0.5)
for i,ch in enumerate(ch_names):
    plt.text(pos[i,0],pos[i,1],ch,va='center',ha='center')
plt.title('Emotiv: 14 channels')

ch_names = sp.eeg.presets.standard_1010_ch
pos, ch = sp.eeg.s1010_get_epos2d(ch_names)

plt.subplot(122)
plt.plot(pos[:,0],pos[:,1],'.',alpha=0.5)
for i,ch in enumerate(ch_names):
    plt.text(pos[i,0],pos[i,1],ch,va='center',ha='center')
plt.title(f'All 10-10 Channels: (n={len(ch_names)})')
plt.show()


# %%
# Topographic Map 10-05 System
# ----------------------------


import numpy as np
import matplotlib.pyplot as plt
import spkit as sp

ch_names = ['AF3','F7','F3','FC5','T7','P7','O1','O2','P8','T8','FC6','F4','F8','AF4']
pos, ch = sp.eeg.s1005_get_epos2d(ch_names)

plt.figure(figsize=(12,5))

plt.subplot(121)
plt.plot(pos[:,0],pos[:,1],'.',alpha=0.5)
for i,ch in enumerate(ch_names):
    plt.text(pos[i,0],pos[i,1],ch,va='center',ha='center')
plt.title('Emotiv: 14 channels')

ch_names = sp.eeg.presets.standard_1005_ch
pos, ch = sp.eeg.s1005_get_epos2d(ch_names)

plt.subplot(122)
plt.plot(pos[:,0],pos[:,1],'.',alpha=0.5)
for i,ch in enumerate(ch_names):
    plt.text(pos[i,0],pos[i,1],ch,va='center',ha='center')
plt.title(f'All 10-05 Channels: (n{len(ch_names)})')
plt.show()



# %%
# MEA: Multi-Electrode Array Processing
# -------------------------------------
#
#
# A full Documentation of MEA Processing Library is added.
#
# :ref:`mea` 
#
# .. image:: https://raw.githubusercontent.com/spkit/spkit.github.io/master/assets/images/docs_fig/mea_proce_2.png
#    :width: 800
#    :align: center
#    :target: ../../modules/bsp_mea.html#mea
#
# .. image:: https://raw.githubusercontent.com/spkit/spkit.github.io/master/assets/images/docs_fig/mea_proce_3.png
#    :width: 800
#    :align: center
#    :target: ../../modules/bsp_mea.html#mea
#
# Check Examples of MEA
