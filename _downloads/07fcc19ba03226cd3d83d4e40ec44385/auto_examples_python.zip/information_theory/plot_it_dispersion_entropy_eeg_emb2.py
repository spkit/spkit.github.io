"""
======================================
Dispersion Entropy with Embedding dim
======================================

Dispersion Entropy is computed by first discretising the signal and then extracting all the
dispersing patterns of given embedding dimension. The ditrubution of patterns determines the
dispersion entropy of signal. If signal have a few patterns with high repetitions compare to others
signal is less random which entails the low entropy. On the other hand, a random signal with no
patterns repetitions more than others leads to high entropy.

"""

import numpy as np
import matplotlib.pyplot as plt
import spkit as sp
print('spkit-version',sp.__version__)

# load sample EEG Signal
X,fs, ch_names = sp.data.eeg_sample_14ch()
x = X[:,0]
x = sp.filter_X(x,band=[1,20],btype='bandpass',verbose=0)
print('EEG Sample x: Shape',x.shape)

t = np.arange(x.shape[0])/fs

#Dispersion Entropy
print('-'*50)
print('Dispersion Entropy with embeding dimention=2')
print('-'*50)

de,prob,patterns_dict,_,_= sp.dispersion_entropy(x,classes=10, scale=1, emb_dim=2, delay=1,return_all=True)
print('Disperssion Entropy: ',de)

plt.figure(figsize=(10,3))
plt.subplot(121)
plt.plot(t,x)
plt.xlim([t[0],t[-1]])
plt.xlabel('time (s)')
plt.ylabel('x')
plt.title('signal: x')
plt.grid()
plt.subplot(122)
plt.stem(np.arange(len(prob)),prob)
plt.xlabel('pattern #')
plt.ylabel('probability')
plt.title(f'Disperssion Entropy: {de:,.4f}')
plt.show()

print('All the patterns found (embeding dimention=2)')
sp.utils.pretty_print(patterns_dict,n=5,show_index=False)