
"""
=============
Scalogram CWT
=============


"""
# Import

import numpy as np
import matplotlib.pyplot as plt

import spkit
print('spkit-version ', spkit.__version__)
import spkit as sp
from spkit.cwt import ScalogramCWT
from spkit.cwt import compare_cwt_example

# Data

x,fs = sp.load_data.eegSample_1ch()
t = np.arange(len(x))/fs

print('shape ',x.shape, t.shape)


# %%
# Comparison Example
# ------------------

# Predefined example script

compare_cwt_example(x,t,fs=fs)


# Signal

plt.figure(figsize=(15,3))
plt.plot(t,x)
plt.xlabel('time')
plt.ylabel('amplitude')
plt.show()


# %%
# Gauss wavelet
# --------------

# Default parameter setting

XW,S = ScalogramCWT(x,t,fs=fs,wType='Gauss',PlotPSD=True)
print(XW.shape, S.shape)


plt.figure(figsize=(15,3))
plt.imshow(np.abs(XW),aspect='auto',origin='lower',cmap='jet',interpolation='sinc')
plt.show()


plt.figure(figsize=(15,3))
plt.imshow(np.log10(np.abs(XW)+0.2),aspect='auto',origin='lower',cmap='jet',interpolation='sinc')
plt.show()


# ### with custom setting

f0 = np.linspace(0.1,10,100)
Q  = np.linspace(0.1,5,100)
XW,S = ScalogramCWT(x,t,fs=fs,wType='Gauss',PlotPSD=True,f0=f0,Q=Q)

# Show wavelets in time and frequency domain

f0 = np.linspace(0.1,10,100)
Q  = np.linspace(0.1,5,100)
XW,S = ScalogramCWT(x,t,fs=fs,wType='Gauss',PlotPSD=True,PlotW=True,f0=f0,Q=Q)


# %%
#  Morlet wavelet
# ---------------

print('Morlet wavelet')
XW,S = ScalogramCWT(x,t,fs=fs,wType='Morlet',PlotPSD=True,)

# %%
#  Gabor wavelet
# --------------


print('Gabor wavelet')
XW,S = ScalogramCWT(x,t,fs=fs,wType='Gabor',PlotPSD=True,)

# %%
#  Poisson wavelet
# ----------------


print('Poisson wavelet')
XW,S = ScalogramCWT(x,t,fs=fs,wType='Poisson',PlotPSD=True,)

# %%
#  Complex Maxican wavelet
# ------------------------


print('Complex Maxican wavelet')
XW,S = ScalogramCWT(x,t,fs=fs,wType='cMaxican',PlotPSD=True,)

# %%
#  Complex Shannon wavelet
# ------------------------


print('Complex Shannon wavelet')
XW,S = ScalogramCWT(x,t,fs=fs,wType='cShannon',PlotPSD=True,)





