"""
===============================
Continues Wavelet Transform -  Scalogram
===============================


"""
import numpy as np
import matplotlib.pyplot as plt

import spkit as sp
print('spkit-version ', sp.__version__)


# load sample EEG Signal

x,fs = sp.load_data.eegSample_1ch()
t = np.arange(len(x))/fs

print('signal shape ',x.shape)

# Predefined comparisio  script
sp.cwt.compare_cwt_example(x,t,fs=fs)

# Gauss Wavelet
XW,S = sp.cwt.ScalogramCWT(x,t,fs=fs,wType='Gauss',PlotPSD=True)


plt.figure(figsize=(15,3))
plt.imshow(np.abs(XW),aspect='auto',origin='lower',cmap='jet',interpolation='sinc')
plt.show()

plt.figure(figsize=(15,3))
plt.imshow(np.log10(np.abs(XW)+0.2),aspect='auto',origin='lower',cmap='jet',interpolation='sinc')
plt.show()

## With parameters settings
f0 = np.linspace(0.1,10,100)
Q  = np.linspace(0.1,5,100)
XW,S = sp.cwt.ScalogramCWT(x,t,fs=fs,wType='Gauss',PlotPSD=True,f0=f0,Q=Q)

print('Morlet wavelet')
XW,S = sp.cwt.ScalogramCWT(x,t,fs=fs,wType='Morlet',PlotPSD=True,)

print('Gabor wavelet')
XW,S = sp.cwt.ScalogramCWT(x,t,fs=fs,wType='Gabor',PlotPSD=True,)

print('Poisson wavelet')
XW,S = sp.cwt.ScalogramCWT(x,t,fs=fs,wType='Poisson',PlotPSD=True,)

print('Complex Maxican wavelet')
XW,S = sp.cwt.ScalogramCWT(x,t,fs=fs,wType='cMaxican',PlotPSD=True,)

print('Complex Shannon wavelet')
XW,S = sp.cwt.ScalogramCWT(x,t,fs=fs,wType='cShannon',PlotPSD=True,)
