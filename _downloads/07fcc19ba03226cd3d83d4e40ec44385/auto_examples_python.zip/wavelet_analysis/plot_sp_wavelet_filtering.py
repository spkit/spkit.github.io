"""
===============================
Wavelet Filtering
===============================

Other than classical frequency filtering, Wavelet filtering is one of common techniques used in signal processing. It allows to filter out short-time duration patterns captured by used wavelet. The patterns to be filtered out depends on the wavelet family (e.g. db3) used and number of level of decomposition.

Algorithmically, it is very straightforward. Decompose a signal x(n), into wavelet coefficients X(k), where each coefficient represents the strength of wavelet pattern at particular time. With some threshold, remove the coefficients by zeroing out and reconstruct the signal back.

The machanism to choose a threshold on the strength of wavelet coefficient depends on the application and objective. To remove the noise and compress the signal, a widely used approach is to filter out all the wavelet coefficients with smaller strength.
Literature [1] suggest the optimal threshold on the wavelet coeffiecient is theta = sigmaxsqrt{2log(N)}, where sigma = median(|X(k)|)/0.6745

There are other methods to choose threshold too. One can choose a (theta =1.5xSD(X(k))) or (theta =IQR(X(k))) as to select the outliers, by standard deviation and interquartile range, respectively.

According to the theory, the optimal threshold should be applied by zeroing out the coefficients below with magnitude lower than threshold (abs(X(k))< theta), and for later two methods of thresholds,standard deviation and interquartile range, the coefficients outside of the threshold should be zeroing out, since they reprepresent the outliers. However, some of the (weired) articles use these thresholds in other-way round.

[1] D.L. Donoho, J.M. Johnstone, Ideal spatial adaptation by wavelet shrinkage Biometrika, 81 (1994), pp. 425-455

For more details, check the Wavelet Analysis Section.

"""

import numpy as np
import matplotlib.pyplot as plt
import spkit as sp
print('spkit-version ', sp.__version__)

import spkit as sp
x = sp.create_signal_1d(n=1000,seed=1)
x = x + 0.1*np.random.randn(len(x))
fs=100
t = np.arange(len(x))/fs

# Wavelet filtering with optimal threshold and db3
xf = sp.wavelet_filtering(x.copy(),wv='db3',threshold='optimal',verbose=1,WPD=False,show=True,fs=fs)


# with SD (Standard Deviation) as threshold criteria
xf = sp.wavelet_filtering(x.copy(),wv='db3',threshold='sd',verbose=1,WPD=False,show=True,fs=fs)

# with IQR (Inter-Quatile range) as threshold criteria
xf = sp.wavelet_filtering(x.copy(),wv='db3',threshold='iqr',verbose=1,WPD=False,show=True,fs=fs)

# Limiting the number of decompositions to 2
xf = sp.wavelet_filtering(x.copy(),wv='db3',threshold='optimal',wpd_maxlevel=2,verbose=1,WPD=False,show=True,fs=fs)

# With Coif4 wavelet
xf = sp.wavelet_filtering(x.copy(),wv='coif4',threshold='optimal',verbose=1,WPD=False,show=True,fs=fs)


plt.figure(figsize=(12,3))
plt.plot(t,x)
plt.xlim([t[0],t[-1]])
plt.grid()
plt.xlabel('time (s)')
plt.show()
